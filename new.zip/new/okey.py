import aiogram
import re
from create_bot import dp, bot
from aiogram.dispatcher.filters.builtin import CommandStart
import pdfkit
from io import BytesIO
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from database import create_bdx, add_userx, get_userx, update_money, add_wait, get_money, get_wait, delete_wait, check_for_wait, get_user_balance_and_id
from selenium import webdriver
import datetime
import re
from aiogram.dispatcher.filters import Text
import time
import asyncio
import random
from aiogram.types import ReplyKeyboardMarkup
import time
from bs4 import BeautifulSoup

from aiogram.utils.exceptions import Throttled
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

from proxy_auth_data import *

from reportlab.pdfgen import canvas
from aiogram.dispatcher import filters
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters import Command

from time import sleep
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from webdriver_manager.firefox import DriverManager
import pickle



options = Options()

# disable webdriver mode
options.set_preference("dom.webdriver.enabled", False)
options.set_preference("dom.webnotifications.enabled", False)
# headless mode
options.headless = True

browser = webdriver.Firefox(
    firefox_binary=r"C:\Program Files\Mozilla Firefox\firefox.exe",
    executable_path=r"C:\Users\yyurc\Downloads\geckodriver.exe")

driver.get("https://naurok.com.ua/login")

time.sleep(60)